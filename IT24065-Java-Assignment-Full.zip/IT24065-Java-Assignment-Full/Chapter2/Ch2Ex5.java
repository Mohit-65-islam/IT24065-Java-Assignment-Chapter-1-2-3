import java.util.Scanner;
public class Ch2Ex5 {
  public static void main(String[] args){
    Scanner input=new Scanner(System.in);
    System.out.print("Enter subtotal and gratuity rate: ");
    double subtotal=input.nextDouble(), rate=input.nextDouble();
    double gratuity=subtotal*rate/100;
    double total=subtotal+gratuity;
    System.out.println("Gratuity: $" + gratuity + " Total: $" + total);
  }
}